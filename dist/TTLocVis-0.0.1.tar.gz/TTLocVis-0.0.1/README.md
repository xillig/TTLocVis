
# TTLocVis
TTLocVis: A Twitter Topic Location Visualization package

##Summary 
##Statement of need
##How to cite 
##Installation
After successful insallation, the user must install the *basemap* package provided [here] manually via *pip*:
```commandline
python3 -m pip install [your basemap wheel here]
```
##Documentation and Usage
You can find the current TTLocVis master branch
documentation at  
##Community guidelines
##License